#!/usr/bin/python3

from pwn import *

print(xor(b"label", 13))
