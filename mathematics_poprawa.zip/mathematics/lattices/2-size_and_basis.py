#!/usr/bin/python3
import numpy as np

v = np.array([4, 6, 2, 5])

# np.linalg.norm returns a float
print(int(np.linalg.norm(v)))