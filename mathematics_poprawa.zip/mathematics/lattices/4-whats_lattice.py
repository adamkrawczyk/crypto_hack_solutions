#!/usr/bin/python3
import numpy as np 

A = [[6, 2, -3], [5, 1, 4], [2, 7, 1]]
print(round(abs(np.linalg.det(A))))