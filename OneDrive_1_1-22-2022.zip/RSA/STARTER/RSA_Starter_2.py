
print(pow(12, 0x10001, 17*23))
